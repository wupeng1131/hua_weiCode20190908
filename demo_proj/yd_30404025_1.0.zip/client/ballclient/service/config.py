p_round_id = 1
p_round_time = 1
p_round_info = 1
p_direct = 1
p_leg_start=0
p_track = 0
p_own_dead = 0