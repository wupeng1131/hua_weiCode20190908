import pickle
import random
import ballclient.service.constants as constants

direction = {1: 'up', 2: 'down', 3: 'left', 4: 'right'}


class task:
    def __init__(self, x, y, value):
        self.x = x
        self.y = y
        self.value = value
        self.info = "task"


class power:
    def __init__(self, x, y, point):
        self.x = x
        self.y = y
        self.point = point


class enemy:
    def __init__(self, id, score, sleep, x, y):
        self.id = id
        self.score = score
        self.sleep = sleep
        self.x = x
        self.y = y


class own:
    def __init__(self, id, score, sleep, x, y, mode):
        self.id = id
        self.score = score
        self.sleep = sleep
        self.x = x
        self.y = y
        self.mode = mode
        #generate wandering

def build_power_list(msg):
    power_list = []
    for info in msg:
        p = power(info['x'], info['y'], info['point'])
        power_list.append(p)

    return power_list



def choose_task(task_list):
    m_list = []
    for t in task_list:
        tmp = t.value
        m_list.append(tmp)
    task_id = m_list.index(max(m_list))
    m_task = task_list[task_id]
    return m_task

def distance(map, x1, y1, x2, y2):
    dist = abs(x1 - x2) + abs(y1 - y2)
    return dist if dist != 0 else 1

def distance_(x1, y1, x2, y2):
    dist = abs(x1 - x2) + abs(y1 - y2)
    return dist if dist != 0 else 1

def read_obj(path):
    file_obj = open(path,'rb')
    bunch = pickle.load(file_obj)
    file_obj.close()
    return bunch

def write_obj(path, obj):
    file_obj = open(path,'wb')
    pickle.dump(obj,file_obj)
    file_obj.close()


def print_matrix(matrix):
    col = matrix.shape[0]
    row = matrix.shape[1]
    for i in range(col):
        print
        for j in range(row):
            print matrix[i][j],

def idx2pos(m_map, idx):
    width = m_map.width
    #height = m_map.height
    x = idx % width
    y = idx // width
    return x,y

def pos2idx(m_map, x, y):
    width = m_map.width
    return y*width + x


def can_go(m_map, x , y):
    if (x >=0 and x < m_map.width) and (y >=0 and y < m_map.height):
        if m_map.map[y][x] == 1:
            return False
        else:
            return True

    else:
        return False


def s_d(m_map, x1,y1,x2,y2):  #move one step
    x1 = int(x1)
    y1 = int(y1)
    x2 = int(x2)
    y2 = int(y2)
    if x2 > x1:
        return 4
    elif x2 < x1:
        return 3
    elif y2 > y1:
        return 2
    elif y2 < y1:
        return 1
    else:
        # print " $$$$$$$$$$$the road has been blocked"
        # m_map.print_map()
        if can_go(m_map,x1-1,y1):  #left
            # print "x1,y1", x1,y1
            # print "x2,y2", x2,y2
            # print "order",order
            # print "path", path
            # print "v:",idx2pos(m_map,v)
            # print "a:",idx2pos(m_map,a)
            # print m_map.map[y1][x1]
            return 3
        elif can_go(m_map,x1+1,y1):     #right
            return 4
        elif can_go(m_map,x1,y1-1):     #up
            return 1
        elif can_go(m_map,x1,y1+1):     #down
            return 2
        else:
            # print "no way to go!!!!!!!!!!!!!!!!!!!!!!!!!!"
            return random.randint(1, 4)



def next_pos(control, x1,y1):
    if control == 1:
        y1 -=1
    elif control == 2:
        y1 += 1
    elif control == 3:
        x1 -= 1
    else:
        x1 += 1
    return x1,y1

def rand_choose(width, height):
    vision = constants.vision
    x = random.randint(0 + vision, width - vision - 1 )
    y = random.randint(0 + vision, height - vision - 1 )
    return x , y



