from __future__ import division
import ballclient.service.constants as constants
from util import *
import copy
from graph import *
# import djs

import random

use_cython = 0

def build_enemy_list(msg):
    enemy_list = []
    for info in msg:
        if info['team']!= constants.team_id:
            e = enemy(info['id'], info['score'], info['sleep'], info['x'], info['y'])
            enemy_list.append(e)
    return enemy_list

def build_own_list(msg,mode):

    own_list = []
    for info in msg:

        if info['team'] == constants.team_id:

            e = own(info['id'], info['score'], info['sleep'], info['x'], info['y'], mode)
            own_list.append(e)
    return own_list


def judge_mode(fish_map, curr_mode):
    team = fish_map.team
    for t in team:
        if t.id == constants.team_id:
            if t.force == curr_mode:
                return 1
            else:
                return 0
    return 0

def distance1(fish, power):
    x1 = fish.x
    y1 = fish.y
    x2 = power.x
    y2 = power.y
    dist = abs(x1 - x2) + abs(y1 - y2)
    return dist



# def can_go(m_map, x , y):
#
#     if (x >=0 and x < m_map.width) and (y >=0 and y <= m_map.height):
#
#         if m_map.map[y][x] == 1:
#             return False
#         else:
#             return True
#
#     else:
#         return False
#
# def rand_choose(a,b,c):
#     l = []
#     l.append(a)
#     l.append(b)
#     l.append(c)
#     idx = random.randint(0, 2) #bug (0,3)
#     return l[idx]
#
#
# def s2d(m_map, x1,y1,x2,y2):
#
#     if x2 > x1:
#         if can_go(m_map, x1+1, y1):
#             return 4
#         else:
#             return rand_choose(1,2,3)
#
#     if x2 < x1:
#         if can_go(m_map, x1-1, y1):
#             return 3
#         else:
#             return rand_choose(1, 2, 4)
#     if y2 > y1:
#         if can_go(m_map, x1, y1+1):
#             return 2
#         else:
#             return rand_choose(1, 3, 4)
#     if y2 < y1:
#         if can_go(m_map, x1, y1-1):
#             return 1
#         else:
#             return rand_choose(2, 3, 4)
#     else:
#         return random.randint(1, 4)


def fish_move(fish_map, player, power_list, enemy_list, own_list, curr_mode):
    me = own(player['id'], player['score'], player['sleep'], player['x'], player['y'],curr_mode)
    m_direct = []
    game_mode = judge_mode(fish_map, curr_mode)

    if game_mode ==1:    #game_mode 1: aggressive
        control = aggressive(fish_map, me, power_list, enemy_list, own_list)
    else:                #game_mode 0:conservative
        control = conservative(fish_map, me, power_list, enemy_list, own_list)

    m_direct.append(direction[control])
    # print m_direct
    return {"team": player['team'], "player_id": player['id'], "move": m_direct}


def aggressive(fish_map, me, power_list, enemy_list, own_list):
    m_graph = graph(fish_map,0)

    task_list = []  # make a task list, the target are power and enemy

    #add task
    # 0
    idx = me.id
    fish_map.wander_task_check(me)
    _task = fish_map.wander_task[idx]
    task_list.append(_task)
    # 1
    for p in power_list:
        x1 = me.x
        y1 = me.y
        x2 = p.x
        y2 = p.y
        dist1 = abs(x1 - x2)
        dist2 = abs(y1 - y2)
        if dist1 <= constants.vision and dist2 <= constants.vision:
            value = p.point / distance_(x1, y1, x2, y2)
            _task = task(x2, y2, value)
            _task.info = "power_task"
            task_list.append(_task)
        else:
            pass
    # 2
    for e in enemy_list:
        x1 = me.x
        y1 = me.y
        x2 = e.x
        y2 = e.y
        dist = distance(fish_map, x1, y1, x2, y2)
        value = 0 / dist  # decrease the value of enemy

        _task = task(x2, y2, value)
        _task.info = "enemy_task"
        task_list.append(_task)
        # if fish_map.has_space(x2-1,y2):
        #     dist = distance(fish_map, x1, y1, x2-1, y2)
        #     value = e.score / dist
        #     _task = task(x2-1, y2, value)
        #     task_list.append(_task)
        #
        # if fish_map.has_space(x2+1,y2):
        #     dist = distance(fish_map, x1, y1, x2 + 1, y2)
        #     value = e.score / dist
        #     _task = task(x2+1, y2, value)
        #     task_list.append(_task)
        #
        # if fish_map.has_space(x2,y2-1):
        #     dist = distance(fish_map, x1, y1, x2 , y2-1)
        #     value = e.score / dist
        #     _task = task(x2, y2-1, value)
        #     task_list.append(_task)
        #
        # if fish_map.has_space(x2,y2+1):
        #     dist = distance(fish_map, x1, y1, x2 , y2+1)
        #     value = e.score / dist
        #     _task = task(x2, y2+1, value)
        #     task_list.append(_task)


    m_task = choose_task(task_list)
    # print "id",me.id,"from(",me.x,me.y,")","to(",m_task.x, m_task.y,")", m_task.info
    control = m_graph.move_direction(fish_map, me.x, me.y, m_task.x, m_task.y)
    return control

    # if not len(power_list) and not len(enemy_list):# no task, wandering
    #     # fish_map.update_wander_task()
    #     idx = me.id
    #     m_task = fish_map.wander_task[idx]
    #     print "fish id",idx,"target(",m_task.x, m_task.y, ")"
    #     if use_cython == 1:
    #         control = djs.move_direction(m_graph.matrix, fish_map, me.x, me.y, m_task.x, m_task.y)
    #     else:
    #         control = m_graph.move_direction(fish_map, me.x, me.y, m_task.x, m_task.y)
    #     return control
    #
    # else:
    #     for p in power_list:
    #         x1 = me.x
    #         y1 = me.y
    #         x2 = p.x
    #         y2 = p.y
    #         dist1 = abs(x1 - x2)
    #         dist2 = abs(y1 - y2)
    #         if dist1 <= constants.vision  and dist2 <= constants.vision:
    #             value = p.point / distance_(x1,y1,x2,y2)
    #             _task = task(x2, y2, value)
    #             task_list.append(_task)
    #         else:
    #             pass
    #     for e in enemy_list:
    #         x1 = me.x
    #         y1 = me.y
    #         x2 = e.x
    #         y2 = e.y
    #         dist = distance(fish_map, x1, y1, x2, y2)
    #         value = 0 / dist  # decrease the value of enemy
    #         _task = task(x2, y2, value)
    #         task_list.append(_task)
    #     #finish task list, find the most valuable task
    #
    #     m_task = choose_task(task_list)
    #     #control = random.randint(1, 4)
    #     # control = s2d(fish_map, me.x, me.y, m_task.x, m_task.y)
    #     if use_cython == 1:
    #         control = djs.move_direction(m_graph.matrix, fish_map, me.x, me.y, m_task.x, m_task.y)
    #     else:
    #         control = m_graph.move_direction(fish_map, me.x, me.y, m_task.x, m_task.y)
    #     # control = m_graph.move_direction(fish_map, 0, 0, 10, 10)
    #
    #     return control



def conservative(fish_map, me, power_list, enemy_list, own_list):

    task_list = []  # make a task list, the target are power and enemy
    tmp_map = copy.deepcopy(fish_map)
    if len(enemy_list):
        for e in enemy_list:
            x1 = me.x
            y1 = me.y
            x2 = e.x
            y2 = e.y
            dist1 = abs(x1 - x2)
            dist2 = abs(y1 - y2)
            if dist1 <= constants.vision and dist2 <= constants.vision:
                tmp_map.add_enemy(e, me)
    m_graph = graph(tmp_map,1)

    # add task
    # 0
    idx = me.id
    fish_map.wander_task_check(me)
    _task = fish_map.wander_task[idx]
    task_list.append(_task)
    # 1
    for p in power_list:
        x1 = me.x
        y1 = me.y
        x2 = p.x
        y2 = p.y
        dist1 = abs(x1 - x2)
        dist2 = abs(y1 - y2)
        if dist1 <= constants.vision and dist2 <= constants.vision:
            if tmp_map.map[x2][y2] ==0:
                value = p.point / distance_(x1, y1, x2, y2)
                _task = task(x2, y2, value)
                _task.info = "power_task"
                task_list.append(_task)
            else:
                # print "!!!!!!!!!!!!! power is enemy"
                pass
        else:
            pass

    m_task = choose_task(task_list)
    # print "id", me.id, "from(", me.x, me.y, ")", "to(", m_task.x, m_task.y, ")",m_task.info
    control = m_graph.move_direction(tmp_map, me.x, me.y, m_task.x, m_task.y)
    return control

    # if not len(power_list):
    #     idx = me.id
    #     m_task = fish_map.wander_task[idx]
    #
    #     if use_cython == 1:
    #         control = djs.move_direction(m_graph.matrix, tmp_map, me.x, me.y, m_task.x, m_task.y)
    #     else:
    #         control = m_graph.move_direction(tmp_map, me.x, me.y, m_task.x, m_task.y)
    #     return control
    #
    # else:
    #     for p in power_list:
    #         x1 = me.x
    #         y1 = me.y
    #         x2 = p.x
    #         y2 = p.y
    #         dist = distance(tmp_map, x1, y1, x2, y2)
    #         value = p.point / dist
    #         _task = task(x2, y2, value)
    #         task_list.append(_task)
    #     m_task = choose_task(task_list)
    #     if use_cython == 1:
    #         control = djs.move_direction(m_graph.matrix, tmp_map, me.x, me.y, m_task.x, m_task.y)
    #     else:
    #         control = m_graph.move_direction(tmp_map, me.x, me.y, m_task.x, m_task.y)
    #     return control



