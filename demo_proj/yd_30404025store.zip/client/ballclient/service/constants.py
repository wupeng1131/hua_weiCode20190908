#global variable here
team_id = None

team_name = "peng" # decided by yourself.

score = []
vision = 4
PRINT = 1
enemy_value = 12
enemy_vision = 8
power_vision = 4
enemy_decay = 2